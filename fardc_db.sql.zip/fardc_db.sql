-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 18, 2015 at 01:15 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fardc_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE IF NOT EXISTS `admin_tbl` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(5000) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`user_id`, `username`, `password`) VALUES
(1, 'Patient', '01122a97dca927210827560cb7d76af8');

-- --------------------------------------------------------

--
-- Table structure for table `contact_tbl`
--

CREATE TABLE IF NOT EXISTS `contact_tbl` (
  `users_id` int(3) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `names` varchar(75) NOT NULL,
  `company` varchar(75) NOT NULL,
  `website` varchar(75) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  PRIMARY KEY (`users_id`),
  UNIQUE KEY `website` (`website`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `contact_tbl`
--

INSERT INTO `contact_tbl` (`users_id`, `email`, `names`, `company`, `website`, `comment`) VALUES
(1, 'patient@gmail.com', 'Patient', 'Papus'' shop', 'www.papus.com', 'Yello my brother!!!'),
(2, 'fabrice@gmail.com', 'Fabrice', 'Mutite', 'Fab''shop', 'Hello i''m very proud of you!');

-- --------------------------------------------------------

--
-- Table structure for table `join_tbl`
--

CREATE TABLE IF NOT EXISTS `join_tbl` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `centre` varchar(20) NOT NULL,
  `year_of_birth` int(11) NOT NULL,
  `month_of_birth` varchar(15) NOT NULL,
  `day_of_birth` int(11) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `education` varchar(50) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `marital` varchar(50) NOT NULL,
  `next_kin` varchar(50) NOT NULL,
  `kin_name` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `join_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `search_tbl`
--

CREATE TABLE IF NOT EXISTS `search_tbl` (
  `question_id` int(11) NOT NULL AUTO_INCREMENT,
  `question` longtext NOT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `search_tbl`
--


-- --------------------------------------------------------

--
-- Table structure for table `users_tbl`
--

CREATE TABLE IF NOT EXISTS `users_tbl` (
  `user_id` int(3) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `year_of_birth` varchar(4) NOT NULL,
  `month_of_birth` varchar(15) NOT NULL,
  `day_of_birth` varchar(2) NOT NULL,
  `nationality` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `code` varchar(4) NOT NULL,
  `phone` int(9) NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `residential_country` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `test_answer` varchar(25) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `password` (`password`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users_tbl`
--

INSERT INTO `users_tbl` (`user_id`, `first_name`, `last_name`, `gender`, `year_of_birth`, `month_of_birth`, `day_of_birth`, `nationality`, `email`, `password`, `code`, `phone`, `occupation`, `residential_country`, `district`, `test_answer`) VALUES
(6, 'Muhamed', 'Slau', 'Male', '1960', 'January', '4', 'Somali', 'muhamed@gmail.com', '358fa067224255a5934965daaf10f9d3', '+257', 477855122, 'Students', 'Uganda', 'Kampala', 'Patient!5421');
